Hart, E. M., & Bell, K. (2015). prism: Download data from the Oregon prism project. https://doi.org/10.5281/zenodo.33663

Hijmans, R. J. (2023). terra: Spatial Data Analysis. https://CRAN.R-project.org/package=terra

PRISM Climate Group, Oregon State University, https://prism.oregonstate.edu

R Core Team. (2021). R: A Language and Environment for Statistical Computing. R Foundation for Statistical Computing. https://www.R-project.org/
